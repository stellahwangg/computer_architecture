#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

struct Job {
    char id;
    int beg_time;
    int end_time;
};

int compare(const void* a, const void* b) {
    if (((struct Job*)a)->end_time != ((struct Job*)b)->end_time) {
        return ((struct Job*)a)->end_time - ((struct Job*)b)->end_time;
    } else if (((struct Job*)a)->beg_time != ((struct Job*)b)->beg_time) {
        return ((struct Job*)a)->beg_time - ((struct Job*)b)->beg_time;
    } else {
        return ((struct Job*)b)->id - ((struct Job*)a)->id;
    }
}

void nonoverlapping(struct Job jobs[], int n) {
    qsort(jobs, n, sizeof(struct Job), compare);

    int last = 0;
    for (int i = 0; i < n; i++) {
        if (jobs[i].beg_time > last) {
            printf("%c\n", jobs[i].id);
            last = jobs[i].end_time;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    int jobcount, timeslots;
    
    if (fscanf(fp, "%d", &jobcount) != 1) {
        perror("reading the number of jobs failed");
        fclose(fp);
        return EXIT_FAILURE;
    }

    if (fscanf(fp, "%d", &timeslots) != 1) {
        perror("reading the number of timeslots failed");
        fclose(fp);
        return EXIT_FAILURE;
    }

    struct Job *jobs = malloc(jobcount * sizeof(struct Job));
    if (!jobs) {
        perror("memory allocation failed");
        fclose(fp);
        return EXIT_FAILURE;
    }

    for (int i = 0; i < jobcount; i++) {
        if (fscanf(fp, " %c %d %d", &jobs[i].id, &jobs[i].beg_time, &jobs[i].end_time) != 3) {
            perror("reading a line for a job failed");
            fclose(fp);
            free(jobs);
            return EXIT_FAILURE;
        }
    }

    fclose(fp);

    nonoverlapping(jobs, jobcount);
    free(jobs);

    return EXIT_SUCCESS;
}

