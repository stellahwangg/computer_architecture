#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <complex.h>

/* Markers used to bound trace regions of interest */
volatile char MARKER_START, MARKER_END;

// Perform matrix multiplication using cache blocking
void cacheBlockedMatMul(size_t n, complex double* a, complex double* b, complex double* c, size_t blockSize) {
    for (size_t kk = 0; kk < n; kk += blockSize) {
        for (size_t ii = 0; ii < n; ii += blockSize) {
            for (size_t jj = 0; jj < n; jj += blockSize) {
                // Iterate over blocks of size blockSize x blockSize
                for (size_t i = ii; i < ii + blockSize && i < n; i++) {
                    for (size_t j = jj; j < jj + blockSize && j < n; j++) {
                        complex double sum = 0 + 0 * I;
                        for (size_t k = kk; k < kk + blockSize && k < n; k++) {
                            sum += a[i * n + k] * b[k * n + j];
                        }
                        c[i * n + j] += sum;
                    }
                }
            }
        }
    }
}

int main(int argc, char* argv[]) {
    /* Record marker addresses */
    FILE* marker_fp = fopen(".marker","w");
    assert(marker_fp);
    fprintf(marker_fp, "%llx\n%llx",
        (unsigned long long int) &MARKER_START,
        (unsigned long long int) &MARKER_END );
    fclose(marker_fp);

    if (argc != 3) {
        printf("Usage: ./matMul <matrix_a_file> <matrix_b_file>\n");
        exit(EXIT_FAILURE);
    }

    FILE* matrix_a_fp = fopen(argv[1], "r");
    if (!matrix_a_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    size_t n;
    int ret = fscanf(matrix_a_fp, "%ld\n", &n);
    assert(ret == 1);
    complex double* a = calloc(n * n, sizeof(complex double));
    for (size_t i = 0; i < n; i++) {
        for (size_t k = 0; k < n; k++) {
            double real, imag;
            ret = fscanf(matrix_a_fp, "(%lf%lfj) ", &real, &imag);
            assert(ret == 2);
            a[i * n + k] = real + imag * I;
        }
        ret = fscanf(matrix_a_fp, "\n");
    }
    fclose(matrix_a_fp);

    FILE* matrix_b_fp = fopen(argv[2], "r");
    if (!matrix_b_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    size_t m;
    ret = fscanf(matrix_b_fp, "%ld\n", &m);
    assert(ret == 1);
    assert(n == m);
    complex double* b = calloc(n * n, sizeof(complex double));
    for (size_t k = 0; k < n; k++) {
        for (size_t j = 0; j < n; j++) {
            double real, imag;
            ret = fscanf(matrix_b_fp, "(%lf%lfj) ", &real, &imag);
            assert(ret == 2);
            b[k * n + j] = real + imag * I;
        }
        ret = fscanf(matrix_b_fp, "\n");
    }
    fclose(matrix_b_fp);

    complex double* c = calloc(n * n, sizeof(complex double));
    MARKER_START = 211;

    // Perform cache blocked matrix multiplication
    size_t blockSize = 2; // Adjust block size based on experiments
    cacheBlockedMatMul(n, a, b, c, blockSize);

    MARKER_END = 211;

    for (size_t i = 0; i < n; i++) {
        for (size_t j = 0; j < n; j++) {
            if (cimag(c[i * n + j]) < 0) {
                printf("(%.12lf%.12lfj) ", creal(c[i * n + j]), cimag(c[i * n + j]));
            } else {
                printf("(%.12lf+%.12lfj) ", creal(c[i * n + j]), cimag(c[i * n + j]));
            }
        }
        printf("\n");
    }

    free(c);
    free(b);
    free(a);
    exit(EXIT_SUCCESS);
}
