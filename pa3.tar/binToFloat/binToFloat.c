#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define EXP_SZ 8
#define FRAC_SZ 23

int main(int argc, char *argv[]) {

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE* fp = fopen(argv[1], "rb");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // Read the binary number representation of a floating-point number
    char buff;
    unsigned int binary = 0;
    for (int i = EXP_SZ + FRAC_SZ; i >= 0; i--) {
        if (fread(&buff, sizeof(char), 1, fp) != 1) {
            fprintf(stderr, "Error reading file\n");
            fclose(fp);
            return EXIT_FAILURE;
        }
        if (buff == '0' || buff == '1') {
            binary |= (buff - '0') << i;
        } else if (buff != ' ' && buff != '\n' && buff != '\t') {
            fprintf(stderr, "Invalid character in the file\n");
            fclose(fp);
            return EXIT_FAILURE;
        }
    }

    fclose(fp);

    // Extracting sign, exponent, and fraction
    int sign = (binary >> (EXP_SZ + FRAC_SZ)) & 1;
    int exponent = (binary >> FRAC_SZ) & ((1 << EXP_SZ) - 1);
    int fraction = binary & ((1 << FRAC_SZ) - 1);

    // Bias for IEEE 754 single-precision floating-point representation
    int bias = (1 << (EXP_SZ - 1)) - 1;

    // Calculating the components of the floating-point number
    int e = exponent - bias;
    double m = 1.0 + fraction / pow(2, FRAC_SZ);

    // Applying the formula to get the final result
    double number = ldexp(m, e);
    number = sign ? -number : number;

    printf("%e\n", number);

    return EXIT_SUCCESS;
}
