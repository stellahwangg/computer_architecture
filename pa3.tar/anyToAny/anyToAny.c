#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

// Author: Pedro Torres

size_t anyToInteger(char* source, int base, int digitCount) {
    // Implement logic to convert the source string to integer representation
    // Remember to return the integer value

    size_t repr = 0;

    for (int i = 0; i < digitCount; i++) {
        char digitChar = source[i];

        // Convert char to digit value
        int digit;
        if (digitChar >= '0' && digitChar <= '9') {
            digit = digitChar - '0';
        } else if (digitChar >= 'A' && digitChar <= 'Z') {
            digit = digitChar - 'A' + 10;
        } else if (digitChar >= 'a' && digitChar <= 'z') {
            digit = digitChar - 'a' + 10;
        } else {
            fprintf(stderr, "Invalid character in the source number: %c\n", digitChar);
            exit(EXIT_FAILURE);
        }

        // Update the representation in the specified base
        repr = repr * base + digit;
    }

    return repr;
}

void integerToAny(char* result, size_t repr, int base) {
    // Implement the logic to convert the represented value to any base
    // Store this value as a string in the 'result' array

    int index = 0;
    do {
        int remainder = repr % base;
        char digitChar;
        if (remainder < 10) {
            digitChar = remainder + '0';
        } else {
            digitChar = remainder - 10 + 'A';
        }

        result[index++] = digitChar;
        repr /= base;
    } while (repr > 0);

    // Reverse the result string
    for (int i = 0, j = index - 1; i < j; i++, j--) {
        char temp = result[i];
        result[i] = result[j];
        result[j] = temp;
    }

    result[index] = '\0'; // Null-terminate the string
}

int main(int argc, char* argv[]) {
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    int digitCount;
    int sourceBase;
    int destBase;

    if (!fscanf(fp, "%d\n", &digitCount)) {
      perror("reading the input digit count failed");
      exit(EXIT_FAILURE);
    }

    if (!fscanf(fp, "%d\n", &sourceBase)) {
      perror("reading the source base failed");
      exit(EXIT_FAILURE);
    }

    if (!fscanf(fp, "%d\n", &destBase)) {
      perror("reading the destination base failed");
      exit(EXIT_FAILURE);
    }

    char* sourceNum = calloc(sizeof(char), digitCount+1);

    if (!fscanf(fp, "%s\n", sourceNum)) {
      perror("reading the source number");
      exit(EXIT_FAILURE);
    }

    size_t repr;

    repr = anyToInteger(sourceNum, sourceBase, digitCount);

    // Size 65 accounts for the largest digit result (64 bit binary) + 1 null operator
    char* result = (char*)calloc(sizeof(char), 65);

    integerToAny(result, repr, destBase);

    // Print the result string
    printf("%s", result);

    free(sourceNum);
    free(result);

    return EXIT_SUCCESS;
}
