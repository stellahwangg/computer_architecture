#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // First, read the minuend (number to be subtracted from)
    char buff;
    bool minuend[CHAR_BIT]; // suggested that you store bits as an array of bools; minuend[0] is the LSB
    for (int i = CHAR_BIT - 1; 0 <= i; i--) { // read MSB first as that is what comes first in the file
        if (fscanf(fp, " %c", &buff) != 1) {
            fprintf(stderr, "Error reading minuend bit %d\n", i);
            fclose(fp);
            return EXIT_FAILURE;
        }
        minuend[i] = (buff == '1');
    }

    // Read an additional newline character
    if (fscanf(fp, "\n") != 0) {
        fprintf(stderr, "Error reading newline character\n");
        fclose(fp);
        return EXIT_FAILURE;
    }

    // Second, read the subtrahend (number to subtract)
    bool subtrahend[CHAR_BIT]; // suggested that you store bits as an array of bools; subtrahend[0] is the LSB
    for (int i = CHAR_BIT - 1; 0 <= i; i--) { // read MSB first as that is what comes first in the file
        if (fscanf(fp, " %c", &buff) != 1) {
            fprintf(stderr, "Error reading subtrahend bit %d\n", i);
            fclose(fp);
            return EXIT_FAILURE;
        }
        subtrahend[i] = (buff == '1');
    }

    // Negate the subtrahend
    // Flip all bits
    for (int i = 0; i < CHAR_BIT; i++) {
        subtrahend[i] = !subtrahend[i];
    }

    // Add one
    bool carry = true;
    for (int i = 0; i < CHAR_BIT; i++) {
        bool sum = minuend[i] ^ subtrahend[i] ^ carry;
        carry = (minuend[i] && subtrahend[i]) || ((minuend[i] ^ subtrahend[i]) && carry);
        minuend[i] = sum;
    }

    // Print the difference bit string
    for (int i = CHAR_BIT - 1; 0 <= i; i--) {
        printf("%d", minuend[i]);
    }
    printf("\n");

    fclose(fp);
    return EXIT_SUCCESS;
}
