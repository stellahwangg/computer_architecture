#include "../graphutils.h"

// A program to find a cycle in a directed graph

// You may use DFS or BFS as needed
struct element {
    graphNode_t node;
    struct element* next;
};

void push(struct element** front, graphNode_t new);
graphNode_t pop(struct element** front);
bool DFS(size_t graphNodeCount, AdjacencyListNode* adjacencyList, int* visited, graphNode_t* parents, graphNode_t parent, graphNode_t current);

void push(struct element** front, graphNode_t new){
    struct element* new_top = (struct element*)malloc(sizeof(struct element));
    new_top->node = new;
    new_top->next = (*front);
    (*front) = new_top;
}

graphNode_t pop(struct element** front){
    struct element* temp;
    graphNode_t temp_close;
    temp = *front
;
    temp_close = temp->node;
    *front = temp->next;
    free(temp);
    return temp_close;
}
//rework logic -- done
bool DFS(size_t graphNodeCount, AdjacencyListNode* adjacencyList, int* visited, graphNode_t* parents, graphNode_t parent, graphNode_t current) {
    if(visited[current] == 0){
        graphNode_t temp = parent;
        struct element* stack = NULL;
        while(temp != current){
            push(&stack, temp);
            temp = parents[temp];
        }
        push(&stack, current);
        while(stack != NULL){
            graphNode_t front = pop(&stack);
            printf("%ld ", front);
        }
        return true;
    } else {
        visited[current] = 0;
    }
    parents[current] = parent;
    AdjacencyListNode* neighbor = adjacencyList[current].next;
    bool isCycle = false;

    while(neighbor){
        isCycle = DFS(graphNodeCount, adjacencyList, visited, parents, current, neighbor->graphNode);
        if(isCycle){
            break;
        }
        neighbor = neighbor -> next;
    }
    visited[current] = 1;
    return isCycle;
}

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);
    bool isCyclic = false;
    int* visited = calloc(graphNodeCount, sizeof(int));
    graphNode_t* parents = calloc(graphNodeCount, sizeof(graphNode_t));

    for (unsigned source=0; source<graphNodeCount; source++) {
        for(int i = 0; i< graphNodeCount; i++){
            visited[i] = -1;
        }
        if(DFS(graphNodeCount,adjacencyList,visited,parents,adjacencyList[source].graphNode, adjacencyList[source].graphNode)){
            isCyclic = true;
            break;
        }
    }
    if (!isCyclic) { 
        printf("DAG\n"); 
    }
    freeAdjList ( graphNodeCount, adjacencyList );
    free (visited);
    free(parents);
    return EXIT_SUCCESS;
}

