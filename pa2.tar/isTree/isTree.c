#include "../graphutils.h" // header for functions to load and free adjacencyList

// A program to determine whether an undirected graph is a tree

// A recursive function that returns true if no cycles found
bool isTreeDFS (
    size_t graphNodeCount,
    AdjacencyListNode* adjacencyList,
    bool* visited,
    graphNode_t parent,
    graphNode_t current
) {

    // First see if current node has already been visited, indicating a cycle found
    if (visited[current]) {
    return false;
}

    // Current node was not already visited, so now mark it as visited

    visited[current] = true;


    // Now iterate through each of the neighboring graph nodes
    AdjacencyListNode* neighbor = adjacencyList[current].next;
    while (neighbor) {
        if (neighbor->graphNode!=parent) {
            // If the neighbor nodes is not the parent node (the node from which we arrived at current), call DFS
            if (!isTreeDFS(graphNodeCount, adjacencyList, visited, current, neighbor->graphNode)) {
            return false; 
        }
        }
        neighbor = neighbor->next;
    }

    // All DFS searches from current node found no cycles, so graph is a tree from this node
    return true;
}

int main(int argc, char* argv[]) {
    // Command-line argument check
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);
    if (graphNodeCount == 0) {
        return EXIT_FAILURE;
    }

    // Print the adjacency list for debugging
    for (size_t source = 0; source < graphNodeCount; source++) {
        AdjacencyListNode* dest = adjacencyList[source].next;

        while (dest) {
            dest = dest->next;
        }
    }

    // Array of boolean variables indicating whether graph node has been visited
    bool* visited = calloc(graphNodeCount, sizeof(bool));
    if (!visited) {
        perror("Memory allocation failed");
        freeAdjList(graphNodeCount, adjacencyList);
        return EXIT_FAILURE;
    }

    // Check if the graph is a tree
    bool isTree = isTreeDFS(graphNodeCount, adjacencyList, visited, -1, 0);

    // Free allocated memory
    free(visited);
    freeAdjList(graphNodeCount, adjacencyList);

    printf(isTree ? "yes\n" : "no\n");

    return EXIT_SUCCESS;
}
