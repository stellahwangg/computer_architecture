#include "../graphutils.h" // header for functions to load and free adjacencyList
#include "../queue/queue.h" // header for queue

// A program to solve a maze that may contain cycles using BFS

int main ( int argc, char* argv[] ) {

    // First, read the query file to get the source and target nodes in the maze
    FILE* fp = fopen(argv[2], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }
    // For example, assuming you read the source and target from the file
    size_t source, target;
    size_t query[2];
    
    for (int i = 0; i < 2; i++)
    {
        fscanf(fp, "%lu", &query[i]);
    }
    
    fclose(fp);
    
    source = query[0];
    target = query[1];

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList = NULL;
    size_t graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);
    if (graphNodeCount == 0) {
        return EXIT_FAILURE;
    }


    // An array that keeps track of who is the parent node of each graph node we visit
    graphNode_t* parents = calloc( graphNodeCount, sizeof(graphNode_t) );
    for (size_t i=0; i<graphNodeCount; i++) {
        parents[i] = -1;
    }

    parents[source] = source;

    // USE A QUEUE TO PERFORM BFS
    Queue queue = { .front=NULL, .back=NULL };

    // Initialize BFS with the source node
    enqueue(&queue, &adjacencyList[source]);

    // Perform BFS
    while (queue.front != NULL) {

        AdjacencyListNode* temp = dequeue(&queue);
        int current = temp -> graphNode;
        if(current == target){
            break;
        }
        
        AdjacencyListNode* neighbor = adjacencyList[current].next;
        while(neighbor != NULL){
            if( neighbor -> graphNode == target){
                parents[neighbor -> graphNode] = current;
                break;
            }
            if(parents[neighbor -> graphNode] == -1){
                parents[neighbor -> graphNode] = current;
                enqueue(&queue, neighbor);
            }

            neighbor = neighbor -> next;
        }

    }

    //Use the parent array to print the maze solution
    int* tracker = calloc(graphNodeCount, sizeof(int));
    int tracker_length = 0;
    int search = target;


    // Free any queued graph nodes that we never visited - fixed
    while (search != source) {
        tracker[tracker_length++] = search;
        search = parents[search];
    }
    tracker[tracker_length++] = source;

    for(int i = tracker_length - 1; i > 0; i--){
        printf("%d %d\n", tracker[i], tracker[i-1]);
    }

    while(queue.front){
        dequeue(&queue);
    }
    free(tracker);
    free(parents);
    freeAdjList(graphNodeCount, adjacencyList);

    return EXIT_SUCCESS;
}
