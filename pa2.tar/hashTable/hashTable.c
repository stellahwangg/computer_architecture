#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define RESTOCK "RESTOCK"
#define SHOW_STOCK "SHOW_STOCK"
#define SALE "SALE"

char* strdup(const char* str);

typedef struct HashNode {
    int count;
    char* album_name;
    int insertion_order;
    struct HashNode* next;
} HashNode;

static HashNode** table = NULL;
static int table_fullness = 0, table_size = 4;

int hash(char* str) {
    unsigned long long hash = 0;
    int len = (int)strlen(str);
    for (int i = 0; i < len; i++)
        hash += str[i] * pow(31, len - (i + 1));
    return hash % table_size;
}

void pretty_print_table() {
    printf("-------- FINAL COUNTS --------\n");
    for (int i = 0; i < table_size; i++) {
        HashNode* current = table[i];
        while (current != NULL) {
            printf("%s: %d\n", current->album_name, current->count);
            current = current->next;
        }
    }
    printf("------------------------------\n");
}

void resize() {
    int old_size = table_size;
    table_size *= 2;
    printf("Resizing the table from %d to %d.\n", old_size, table_size);
    HashNode** new_table = calloc(table_size, sizeof(HashNode*));

    // Rehash all elements into the new table
    for (int i = 0; i < old_size; i++) {
        HashNode* current = table[i];
        while (current != NULL) {
            HashNode* next = current->next;
            int index = hash(current->album_name);
            current->next = new_table[index];
            new_table[index] = current;
            current = next;
        }
    }

    free(table);
    table = new_table;
}

void update(char* album, int k) {
    int index = hash(album);

    // Check if the album is already in the hash table
    HashNode* current = table[index];
    while (current != NULL) {
        if (strcmp(current->album_name, album) == 0) {
            // Album found, update count
            current->count += k;
            return;
        }
        current = current->next;
    }

    // Album not found, create a new node
    HashNode* new_node = malloc(sizeof(HashNode));
    if (new_node == NULL) {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    new_node->album_name = strdup(album);
    new_node->count = k;
    new_node->next = table[index];
    table[index] = new_node;

    // Check if the table needs resizing
    table_fullness++;
    if (table_fullness >= table_size / 2) {
        resize();
    } else if (table_fullness >= table_size * 0.75) {
        resize();
    }
}

int retrieve(char* album_name) {
    int index = hash(album_name);
    HashNode* current = table[index];

    while (current != NULL) {
        if (strcmp(current->album_name, album_name) == 0) {
            // Album found, return count
            return current->count;
        }
        current = current->next;
    }

    // Album not found
    return -1;
}

void free_table() {
    for (int i = 0; i < table_size; i++) {
        HashNode* current = table[i];
        while (current != NULL) {
            HashNode* next = current->next;
            free(current->album_name);
            free(current);
            current = next;
        }
    }
    free(table);
}

int main(int argc, char* argv[]) {
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    if (!fscanf(fp, "%d\n", &table_size)) {
        perror("Reading the initial size of the table failed.\n");
        exit(EXIT_FAILURE);
    }

    table = calloc(table_size, sizeof(HashNode*));

    char command[20], album[150];
    int count;
    while (fscanf(fp, "%s %d %[^\n]s", command, &count, album) == 3) {
        if (strcmp(command, SALE) == 0) {
            int stock = retrieve(album);
            if (stock == -1) {
                printf("No stock of %s.\n", album);
            } else if (stock < count) {
                printf("Not enough stock of %s.\n", album);
            } else {
                update(album, -count);
            }
        } else if (strcmp(command, RESTOCK) == 0) {
            update(album, count);
        } else if (strcmp(command, SHOW_STOCK) == 0) {
            int stock = retrieve(album);
            if (stock == -1) {
                printf("No stock of %s.\n", album);
            } else {
                printf("Current stock of %s: %d\n", album, stock);
            }
        }
    }

    pretty_print_table();
    free_table();
    fclose(fp);
    return 0;
}
