#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

bool is_prime(long n){

  if (n<2)
    return false;

  for (int i=2; i<=sqrt(n); i++)
    if ((n%i)==0)
      return false;

  return true;
}

long perfect_number(long num){
  long divisors_sum = 1;
  for(long i = 2; i <= sqrt(num); i ++){
    if(num % i == 0){
      divisors_sum += i;
      if(i != num / i){
        divisors_sum += num / i;
      }

    }
  }
  //check if the sum of divisors is equal to num
  //printf(" checkpoint1 %ld\n", divisors_sum);
  if(divisors_sum == num){
    return divisors_sum;
  } else {
    return -1;
  }

}

long mersenne_prime(long perf_num){
  long ex = 0;
  long p = perfect_number(perf_num);
  if( p !=  -1 ){
    while((p & 1) == 0){
      p >>= 1;
      ex++;
      
    }
  

  //check if 2^p-1 is a prime number
    long m_prime = (2 << ex) - 1;
    //printf("checkpoint2: %ld \n", m_prime);
    if(is_prime(m_prime)){
      return m_prime;
    } 
  }

  return -1;

}

int main(int argc, char* argv[]) {

  // Open the filename given as the first command line argument for reading
  FILE* fp = fopen(argv[1], "r");
  if (!fp) {
    perror("fopen failed");
    return EXIT_FAILURE;
  }
  char buf[256];

  char* string = fgets(buf, 256, fp);
  long x = atol(string);

  /* ... */
  long m_p = mersenne_prime(x);

  if (m_p != -1) {
    // Printing in C.
    // %d is the format specifier for integer numbers.
    // \n is the newline character
    printf( "%ld \n", m_p );
  } else {
    printf("-1\n");
  }
  return 0;
}